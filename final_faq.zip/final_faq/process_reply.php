<?php
// process_reply.php

// Connect to the database
$conn = new mysqli('localhost', 'root', '', 'final_db');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the form data
$faq_id = $_POST['faq_id'];
$name = $_POST['name'];
$email = $_POST['email'];
$comment = $_POST['comment'];

// Insert the reply into the database
$sql = "INSERT INTO ansreply (faq_id, name, email, comment) VALUES ('$faq_id', '$name', '$email', '$comment')";

if ($conn->query($sql) === TRUE) {
    echo "New reply created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

// Redirect back to the FAQ page
header("Location: index.php");
exit();
?>
