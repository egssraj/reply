<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAQ Section</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <section>
        <div class="main-row">
            <div class="main1">
                <form action="process_form.php" method="POST">
                    <label for="userInput">Enter your question:</label><br />
                    <input type="text" id="userInput" name="userInput" required /><br /><br />
                    <input type="submit" value="Submit" />
                </form>
            </div>
            <div class="main2">
                <div class="faq-container">
                    <h1>Frequently Asked Questions</h1>
                    <?php
                        // Connect to the database
                        $conn = new mysqli('localhost', 'root', '', 'final_db');

                        // Check connection
                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        }

                        // Fetch FAQs from the database
                        $sql = "SELECT * FROM addques";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            // Output data of each row
                            while($row = $result->fetch_assoc()) {
                                $faq_id = $row["id"];
                                echo '<div class="faq">';
                                echo '<div class="faq-question">';
                                echo '<h3><a href="Leave-reply.php?faq_id=' . htmlspecialchars($faq_id) . '">' . htmlspecialchars($row["question"]) . '</a></h3>';
                                echo '</div>';
                                echo '<div class="faq-answer">';
                                echo '<p>' . htmlspecialchars($row["answer"]) . '</p>';
                                
                                // Fetch replies for the current FAQ
                                $sql_replies = "SELECT * FROM ansreply WHERE faq_id = $faq_id";
                                $result_replies = $conn->query($sql_replies);
                                
                                if ($result_replies->num_rows > 0) {
                                    echo '<div class="replies">';
                                    while($reply = $result_replies->fetch_assoc()) {
                                        // echo '<div class="reply">';
                                        echo '<p>' . htmlspecialchars($reply["comment"]) . '</p>';
                                        // echo '<p><em>' . htmlspecialchars($reply["created_at"]) . '</em></p>';
                                        echo '</div>';
                                    }
                                    echo '</div>';
                                } else {
                                    echo "<p>No comments yet.</p>";
                                }

                                echo '</div>';
                                echo '</div>';
                            }
                        } else {
                            echo "No FAQs found.";
                        }
                        $conn->close();
                    ?>
                </div>
            </div>
        </div>
    </section>

    <script>

        // script.js

document.addEventListener('DOMContentLoaded', () => {
    const faqQuestions = document.querySelectorAll('.faq-question');

    faqQuestions.forEach(question => {
        question.addEventListener('click', () => {
            const answer = question.nextElementSibling;
            answer.style.display = answer.style.display === 'block' ? 'none' : 'block';
        });
    });
});

    </script>
</body>
</html>
