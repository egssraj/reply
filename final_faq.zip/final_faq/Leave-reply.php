<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave a Reply</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php
    // Connect to the database
    $conn = new mysqli('localhost', 'root', '', 'final_db');

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get the FAQ ID from the URL
    $faq_id = isset($_GET['faq_id']) ? (int) $_GET['faq_id'] : 0;

    // Fetch the specific FAQ from the database
    $sql = "SELECT * FROM addques WHERE id = $faq_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Output data of the specific FAQ
        $row = $result->fetch_assoc();
        echo '<h1>' . htmlspecialchars($row["question"]) . '</h1>';
        echo '<p>' . htmlspecialchars($row["answer"]) . '</p>';
    } else {
        echo "FAQ not found.";
    }
    $conn->close();
    ?>

    <section>
        <h1>Leave a Reply</h1>
        <form action="process_reply.php" method="POST">
            <input type="hidden" name="faq_id" value="<?php echo $faq_id; ?>" />
            <label for="name">Name:</label><br />
            <input type="text" id="name" name="name" required /><br /><br />

            <label for="email">Email:</label><br />
            <input type="email" id="email" name="email" required /><br /><br />

            <label for="comment">Comment:</label><br />
            <textarea id="comment" name="comment" rows="4" required></textarea><br /><br />

            <input type="submit" value="Submit" />
        </form>
    </section>
</body>
</html>
