<?php
// process_form.php

// Connect to the database
$conn = new mysqli('localhost', 'root', '', 'faq_db');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the form data
$userInput = $_POST['userInput'];

// Insert the question into the database
$sql = "INSERT INTO faqs (question) VALUES ('$userInput')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

// Redirect back to the main page
header("Location: index.php");
exit();
?>
