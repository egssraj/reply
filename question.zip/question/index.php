<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
       

body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.main-row {
    display: flex;
    justify-content: space-between;
    padding: 20px;
}

.main1, .main2 {
    width: 48%;
}

.faq-container {
    max-width: 800px;
    margin: 0 auto;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

h1 {
    text-align: center;
    color: #333;
}

.faq {
    margin-bottom: 10px;
    border-bottom: 1px solid #ddd;
}

.faq-question {
    background-color: #f7f7f7;
    padding: 15px;
    cursor: pointer;
}

.faq-question h3 {
    margin: 0;
    font-size: 1.1em;
    color: #333;
}

.faq-answer {
    display: none;
    padding: 15px;
    background-color: #fff;
    border-top: 1px solid #ddd;
    transition: max-height 0.2s ease-out;
}

.faq-answer p {
    margin: 0;
    color: #555;
}

    </style>
</head>
<body>
    <section>
        <div class="main-row">
            <div class="main1">
                <form action="process_form.php" method="POST">
                    <label for="userInput">Enter your question:</label><br />
                    <input type="text" id="userInput" name="userInput" required/><br /><br />
                    <input type="submit" value="Submit" />
                </form>
            </div>
            <div class="main2">
                <div class="faq-container">
                    <h1>Frequently Asked Questions</h1>
                    <?php
                        // Connect to the database
                        $conn = new mysqli('localhost', 'root', '', 'faq_db');

                        // Check connection
                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        }

                        // Fetch FAQs from the database
                        $sql = "SELECT * FROM faqs";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            // Output data of each row
                            while($row = $result->fetch_assoc()) {
                                echo '<div class="faq">';
                                echo '<div class="faq-question">';
                                echo '<h3><a href="Leave-reply.php?faq_id=' . htmlspecialchars($row["id"]) . '">' . htmlspecialchars($row["question"]) . '</a></h3>';
                                echo '</div>';
                                echo '<div class="faq-answer">';
                                
                                echo '</div>';
                                echo '</div>';
                            }
                        } else {
                            echo "No FAQs found.";
                        }
                        $conn->close();
                    ?>
                </div>
            </div>
        </div>
    </section>
    

    <!-- <script>
        // script.js

document.addEventListener('DOMContentLoaded', () => {
    const faqQuestions = document.querySelectorAll('.faq-question');

    faqQuestions.forEach(question => {
        question.addEventListener('click', () => {
            const answer = question.nextElementSibling;
            answer.style.display = answer.style.display === 'block' ? 'none' : 'block';
        });
    });
});

    </script> -->
</body>
</html>
