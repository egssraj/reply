<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave a Reply</title>
    <style>
        /* styles.css */

body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

section {
    max-width: 800px;
    margin: 50px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

h1, h2 {
    text-align: center;
    color: #333;
}

form {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

label {
    font-weight: bold;
    color: #555;
}

input[type="text"], input[type="email"], textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 4px;
}

input[type="submit"] {
    align-self: center;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    background-color: #28a745;
    color: white;
    cursor: pointer;
}

input[type="submit"]:hover {
    background-color: #218838;
}

.reply {
    border-bottom: 1px solid #ddd;
    padding: 10px 0;
}
.reply .user-name {
    font-size: 25px;
    font-weight: 400;
    margin-bottom: 10px;
}
.post-date{
    font-size: 14px;
    padding-bottom: 20px;
}

.reply p {
    margin: 5px 0;
}

    </style>
</head>
<body>

<section>
        <h2>Recent Replies</h2>
        <div id="replies-container">
            <?php
                // Connect to the database
                $conn = new mysqli('localhost', 'root', '', 'faq_db');

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Fetch replies from the database
                $sql = "SELECT * FROM faqs ORDER BY created_at DESC";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // Output data of each row
                    while($row = $result->fetch_assoc()) {
                        echo '<div class="reply">';
                        echo '<p class="user-name">' . htmlspecialchars($row["name"]) . '</p>';
                        echo '<p class="post-date"><em>' . htmlspecialchars($row["created_at"]) . '</em></p>';
                        echo '<p>' . htmlspecialchars($row["comment"]) . '</p>';
                        echo '</div>';
                    }
                } else {
                    echo "No replies yet.";
                }
                $conn->close();
            ?>
        </div>
    </section>
    <section>
        <h1>Leave a Reply</h1>
        <form action="process_reply.php" method="POST">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required /><br />

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required /><br />

            <label for="comment">Comment:</label>
            <textarea id="comment" name="comment" rows="4" required></textarea><br />

            <input type="submit" value="Submit" />
        </form>
    </section>

    
</body>
</html>
